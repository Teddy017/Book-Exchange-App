package com.example.bookex

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CartFragment : Fragment() {

    private lateinit var cartRecyclerView: RecyclerView
    private lateinit var cartAdapter: CartAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_cart, container, false)

        cartRecyclerView = view.findViewById(R.id.cartRecyclerView)
        cartRecyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Pass the context to getCartItems()
        cartAdapter = CartAdapter(ShoppingCart.getCartItems(requireContext())) { item ->
            // Remove item from cart
            ShoppingCart.removeItemFromCart(requireContext(), item)
            cartAdapter.updateCart(ShoppingCart.getCartItems(requireContext()))
            Toast.makeText(requireContext(), "${item.title} removed from cart", Toast.LENGTH_SHORT).show()
        }

        cartRecyclerView.adapter = cartAdapter

        return view
    }
}