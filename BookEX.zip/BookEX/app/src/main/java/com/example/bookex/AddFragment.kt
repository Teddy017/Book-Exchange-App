package com.example.bookex

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.firebase.auth.FirebaseAuth
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.util.*

class AddFragment : Fragment() {

    // Constants
    private val PICK_IMAGE_REQUEST = 1

    // Firebase references
    private val storageReference = FirebaseStorage.getInstance().reference
    private val db = FirebaseFirestore.getInstance()

    // UI elements
    private var imageUri: Uri? = null
    private lateinit var imageView: ImageView
    private lateinit var titleEditText: EditText
    private lateinit var priceEditText: EditText
    private lateinit var descriptionEditText: EditText
    private lateinit var categorySpinner: Spinner
    private lateinit var publishButton: Button
    private lateinit var progressBar: ProgressBar // Progress bar for loading

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_add, container, false)

        // Initialize UI elements
        imageView = view.findViewById(R.id.add_image_icon)
        titleEditText = view.findViewById(R.id.et_title)
        priceEditText = view.findViewById(R.id.et_price)
        descriptionEditText = view.findViewById(R.id.editTextTextMultiLine)
        categorySpinner = view.findViewById(R.id.spinner_category)
        publishButton = view.findViewById(R.id.btn_publish)
        progressBar = view.findViewById(R.id.progressBar) // Add progress bar to the layout

        // Set up click listener to open the gallery
        imageView.setOnClickListener { openGallery() }

        // Set up click listener for the publish button
        publishButton.setOnClickListener { uploadImageAndPublish() }

        // Request permissions
        requestStoragePermission()

        // Set up the category spinner
        val categories = arrayOf("Select Category", "Novel", "Sci_Fi" , "Guide", "Education")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, categories)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categorySpinner.adapter = adapter

        return view
    }

    // Function to open the gallery and select an image
    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    // Handle the result of the gallery intent
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            imageUri = data.data
            imageView.setImageURI(imageUri) // Display the selected image
        }
    }

    // Request permission to read storage
    private fun requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                PICK_IMAGE_REQUEST
            )
        }
    }

    // Function to upload the image and publish the item
    private fun uploadImageAndPublish() {
        // Ensure an image is selected
        if (imageUri == null) {
            Toast.makeText(requireContext(), "Please select an image", Toast.LENGTH_SHORT).show()
            return
        }

        // Get reference to Firebase Storage with a unique filename
        val fileRef = storageReference.child("items/${UUID.randomUUID()}.jpg")

        // Show the progress bar while uploading
        progressBar.visibility = View.VISIBLE
        publishButton.isEnabled = false // Disable the publish button during upload

        // Upload the image to Firebase Storage
        fileRef.putFile(imageUri!!)
            .addOnSuccessListener {
                // Get the download URL of the uploaded image
                fileRef.downloadUrl.addOnSuccessListener { downloadUrl ->
                    // Call function to publish the item with the image URL
                    publishItem(downloadUrl.toString())
                }
            }
            .addOnFailureListener { exception ->
                progressBar.visibility = View.GONE
                publishButton.isEnabled = true
                Toast.makeText(requireContext(), "Image upload failed: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    // In your AddFragment, modify the publishItem() function to include userId:
    private fun publishItem(imageUrl: String) {
        // Get input values
        val title = titleEditText.text.toString().trim()
        val price = priceEditText.text.toString().trim()
        val description = descriptionEditText.text.toString().trim()
        val category = categorySpinner.selectedItem.toString()

        // Get the current user ID
        val userId = FirebaseAuth.getInstance().currentUser?.uid

        // Validate inputs
        if (title.isEmpty() || price.isEmpty() || description.isEmpty() || category == "Select Category" || userId == null) {
            Toast.makeText(requireContext(), "All fields are required", Toast.LENGTH_SHORT).show()
            progressBar.visibility = View.GONE
            publishButton.isEnabled = true
            return
        }
        // Create an item data object
        // Create an item data object
        val item = hashMapOf(
            "title" to title,
            "price" to price,
            "description" to description,
            "category" to category,
            "imageUrl" to imageUrl,
            "timestamp" to System.currentTimeMillis(),
            "userId" to userId  // Include the current user ID
        )

        // Add item data to Firestore
        db.collection("items")
            .add(item)
            .addOnSuccessListener {
                progressBar.visibility = View.GONE
                publishButton.isEnabled = true
                Toast.makeText(requireContext(), "Item published successfully", Toast.LENGTH_SHORT).show()
                clearFields()
            }
            .addOnFailureListener { exception ->
                progressBar.visibility = View.GONE
                publishButton.isEnabled = true
                Toast.makeText(requireContext(), "Failed to publish item: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }


    // Function to clear fields after successful upload
    private fun clearFields() {
        titleEditText.text.clear()
        priceEditText.text.clear()
        descriptionEditText.text.clear()
        categorySpinner.setSelection(0)
        imageView.setImageResource(R.drawable.placeholder) // Reset to a placeholder image
        imageUri = null
    }
}