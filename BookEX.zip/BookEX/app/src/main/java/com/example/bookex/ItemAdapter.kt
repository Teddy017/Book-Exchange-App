package com.example.bookex

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class ItemAdapter(
    private val itemList: List<Item>,
    private val fragmentActivity: FragmentActivity // Pass the activity context for fragment transactions
) : RecyclerView.Adapter<ItemAdapter.ItemViewHolder>() {

    inner class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val itemImage: ImageView = itemView.findViewById(R.id.itemImage)
        val itemTitle: TextView = itemView.findViewById(R.id.itemTitle)
        val itemPrice: TextView = itemView.findViewById(R.id.itemPrice)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_grid, parent, false)
        return ItemViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val currentItem = itemList[position]

        // Load image using Glide
        Glide.with(holder.itemView.context)
            .load(currentItem.imageUrl)
            .into(holder.itemImage)

        holder.itemTitle.text = currentItem.title
        holder.itemPrice.text = "Price: ${currentItem.price}"

        // Set click listener on the ImageView to navigate to ItemDetailFragment
        holder.itemImage.setOnClickListener {
            // Create an instance of ItemDetailFragment with item details, including description
            val itemDetailFragment = ItemDetailFragment.newInstance(
                currentItem.imageUrl,
                currentItem.title,
                "Price: ${currentItem.price}",
                currentItem.description // Pass description here
            )
            val fragmentManager: FragmentManager = fragmentActivity.supportFragmentManager
            val fragmentTransaction: FragmentTransaction = fragmentManager.beginTransaction()
            fragmentTransaction.replace(R.id.fragment_container, itemDetailFragment) // Use your actual fragment container ID
            fragmentTransaction.addToBackStack(null) // Optional: adds to back stack
            fragmentTransaction.commit() // Commit the transaction
        }
    }

    override fun getItemCount(): Int {
        return itemList.size
    }
}
