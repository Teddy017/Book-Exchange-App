package com.example.bookex

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class HomeFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var itemAdapter: ItemAdapter
    private var itemList: MutableList<Item> = mutableListOf()
    private val db = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = GridLayoutManager(requireContext(), 2) // 2 columns for grid layout

        // Initialize adapter with the item list and pass fragment activity
        itemAdapter = ItemAdapter(itemList, requireActivity()) // Pass the activity context here
        recyclerView.adapter = itemAdapter

        // Load items from Firestore
        loadItems()

        return view
    }

    private fun loadItems() {
        db.collection("items")
            .orderBy("timestamp", Query.Direction.DESCENDING) // Order by timestamp in descending order (newest first)
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Toast.makeText(requireContext(), "Failed to load items: ${e.message}", Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }

                if (snapshot != null && !snapshot.isEmpty) {
                    itemList.clear() // Clear the list to avoid duplication
                    for (document in snapshot.documents) {
                        val item = document.toObject(Item::class.java)
                        if (item != null) {
                            itemList.add(item) // Add item to the list
                        }
                    }
                    itemAdapter.notifyDataSetChanged() // Notify adapter that the data has changed
                } else {
                    Toast.makeText(requireContext(), "No items found", Toast.LENGTH_SHORT).show()
                }
            }
    }
}
