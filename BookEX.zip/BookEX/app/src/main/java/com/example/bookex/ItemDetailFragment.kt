package com.example.bookex

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ItemDetailFragment : Fragment() {

    private lateinit var itemImageView: ImageView
    private lateinit var itemTitleTextView: TextView
    private lateinit var itemPriceTextView: TextView
    private lateinit var itemDescriptionTextView: TextView
    private lateinit var addToCartButton: Button
    private lateinit var buyButton: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_item_detail, container, false)

        // Initialize views
        itemImageView = view.findViewById(R.id.itemImageView)
        itemTitleTextView = view.findViewById(R.id.itemTitleTextView)
        itemPriceTextView = view.findViewById(R.id.itemPriceTextView)
        itemDescriptionTextView = view.findViewById(R.id.itemDescriptionTextView)
        addToCartButton = view.findViewById(R.id.addToCartButton)
        buyButton = view.findViewById(R.id.buyButton)

        // Retrieve arguments safely
        val itemImage = arguments?.getString(ARG_ITEM_IMAGE) ?: return view
        val itemTitle = arguments?.getString(ARG_ITEM_TITLE) ?: return view
        val itemPrice = arguments?.getString(ARG_ITEM_PRICE) ?: return view
        val itemDescription = arguments?.getString(ARG_ITEM_DESCRIPTION) ?: return view

        // Load image and set text
        Glide.with(this).load(itemImage).into(itemImageView)
        itemTitleTextView.text = itemTitle
        itemPriceTextView.text = itemPrice
        itemDescriptionTextView.text = itemDescription

        // Set button click listeners
        addToCartButton.setOnClickListener {
            val cartItem = CartItem(itemTitle!!, itemPrice!!, itemImage!!)

            // Check if the item is already in the cart
            val cartItems = ShoppingCart.getCartItems(requireContext())
            val itemExists = cartItems.any { it.title == cartItem.title && it.price == cartItem.price }

            if (itemExists) {
                // Show a message if the item is already in the cart
                Toast.makeText(requireContext(), "$itemTitle is already in the cart", Toast.LENGTH_SHORT).show()
            } else {
                // Add the item to the cart if it doesn't already exist
                ShoppingCart.addItemToCart(requireContext(), cartItem)
                Toast.makeText(requireContext(), "$itemTitle added to cart", Toast.LENGTH_SHORT).show()
            }
        }


        buyButton.setOnClickListener {
            // Logic to handle buying the item
            Toast.makeText(requireContext(), "Proceeding to buy $itemTitle", Toast.LENGTH_SHORT).show()
        }

        return view
    }

    private fun addItemToCart(cartItem: CartItem) {
        // Retrieve the existing cart from SharedPreferences
        val sharedPreferences = requireContext().getSharedPreferences("cart_prefs", Context.MODE_PRIVATE)
        val cartItemsJson = sharedPreferences.getString("cart_items", null)
        val cartItems: MutableList<CartItem> = if (!cartItemsJson.isNullOrEmpty()) {
            val type = object : TypeToken<MutableList<CartItem>>() {}.type
            Gson().fromJson(cartItemsJson, type)
        } else {
            mutableListOf()
        }

        // Add the new item to the cart
        cartItems.add(cartItem)

        // Save the updated cart back to SharedPreferences
        with(sharedPreferences.edit()) {
            val updatedCartJson = Gson().toJson(cartItems)
            putString("cart_items", updatedCartJson)
            apply()
        }
    }

    companion object {
        private const val ARG_ITEM_IMAGE = "item_image"
        private const val ARG_ITEM_TITLE = "item_title"
        private const val ARG_ITEM_PRICE = "item_price"
        private const val ARG_ITEM_DESCRIPTION = "item_description"

        fun newInstance(imageUrl: String, title: String, price: String, description: String): ItemDetailFragment {
            val fragment = ItemDetailFragment()
            val args = Bundle().apply {
                putString(ARG_ITEM_IMAGE, imageUrl)
                putString(ARG_ITEM_TITLE, title)
                putString(ARG_ITEM_PRICE, price)
                putString(ARG_ITEM_DESCRIPTION, description)
            }
            fragment.arguments = args
            return fragment
        }
    }
}
