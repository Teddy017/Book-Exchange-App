package com.example.bookex

data class CartItem(val title: String, val price: String, val imageUrl: String)

object Cart {
    private val cartItems = mutableListOf<CartItem>()

    fun addItemToCart(item: CartItem) {
        cartItems.add(item)
    }

    fun getCartItems(): List<CartItem> {
        return cartItems
    }

    fun removeItemFromCart(item: CartItem) {
        cartItems.remove(item)
    }
}
