package com.example.bookex

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object ShoppingCart {

    private const val PREFS_NAME = "cart_prefs"
    private const val CART_ITEMS_KEY = "cart_items"

    fun getCartItems(context: Context): MutableList<CartItem> {
        val sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val cartItemsJson = sharedPreferences.getString(CART_ITEMS_KEY, null)
        return if (!cartItemsJson.isNullOrEmpty()) {
            val type = object : TypeToken<MutableList<CartItem>>() {}.type
            Gson().fromJson(cartItemsJson, type)
        } else {
            mutableListOf()
        }
    }

    fun addItemToCart(context: Context, cartItem: CartItem) {
        val cartItems = getCartItems(context)
        cartItems.add(cartItem)
        saveCartItems(context, cartItems)
    }

    fun removeItemFromCart(context: Context, cartItem: CartItem) {
        val cartItems = getCartItems(context)
        cartItems.remove(cartItem)
        saveCartItems(context, cartItems)
    }

    private fun saveCartItems(context: Context, cartItems: MutableList<CartItem>) {
        val sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        with(sharedPreferences.edit()) {
            val updatedCartJson = Gson().toJson(cartItems)
            putString(CART_ITEMS_KEY, updatedCartJson)
            apply()
        }
    }
}
