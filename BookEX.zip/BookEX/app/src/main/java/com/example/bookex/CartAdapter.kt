package com.example.bookex

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class CartAdapter(private var cartItems: List<CartItem>, private val onRemoveClicked: (CartItem) -> Unit) :
    RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.cart_item, parent, false)
        return CartViewHolder(view)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val item = cartItems[position]

        // Bind data to views
        holder.itemTitleTextView.text = item.title
        holder.itemPriceTextView.text = item.price
        Glide.with(holder.itemImageView.context).load(item.imageUrl).into(holder.itemImageView)

        // Remove button click listener
        holder.removeButton.setOnClickListener {
            onRemoveClicked(item)
        }

        // Contact seller button click listener
        holder.contactSellerButton.setOnClickListener {
            // Logic to contact the seller
        }
    }

    override fun getItemCount(): Int = cartItems.size

    fun updateCart(newCartItems: List<CartItem>) {
        cartItems = newCartItems
        notifyDataSetChanged()
    }

    class CartViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val itemImageView: ImageView = itemView.findViewById(R.id.cartItemImageView)
        val itemTitleTextView: TextView = itemView.findViewById(R.id.cartItemTitleTextView)
        val itemPriceTextView: TextView = itemView.findViewById(R.id.cartItemPriceTextView)
        val removeButton: Button = itemView.findViewById(R.id.removeButton)
        val contactSellerButton: Button = itemView.findViewById(R.id.contactSellerButton)
    }
}