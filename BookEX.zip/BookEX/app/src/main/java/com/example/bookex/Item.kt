package com.example.bookex

import java.util.UUID

data class Item(
    var id: String = UUID.randomUUID().toString(),
    var title: String = "",
    var price: String = "",
    var description: String = "",
    var category: String = "",
    var imageUrl: String = "",
    var timestamp: Long = System.currentTimeMillis(),
    var userId: String = ""
) {
    override fun toString(): String {
        return "Item(title='$title', price='$price', description='$description', category='$category', imageUrl='$imageUrl', timestamp=$timestamp)"
    }

    fun isValid(): Boolean {
        return title.isNotEmpty() && price.isNotEmpty() && description.isNotEmpty() && category.isNotEmpty()
    }
}
