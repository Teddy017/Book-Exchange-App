package com.example.bookex

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import de.hdodenhof.circleimageview.CircleImageView

// Define the parameters as constants (already done in your code)
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [AboutUsFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class AboutUsFragment : Fragment() {

    // Declare the CircleImageView for social media buttons
    private lateinit var instagramImageView: CircleImageView
    private lateinit var facebookImageView: CircleImageView
    private lateinit var linkedinImageView: CircleImageView

    // Parameters (optional, as per your original code)
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_about_us, container, false)

        // Initialize CircleImageViews for social media links
        instagramImageView = view.findViewById(R.id.instagram)
        facebookImageView = view.findViewById(R.id.facebook)
        linkedinImageView = view.findViewById(R.id.linkin)

        // Set click listeners for social media icons
        instagramImageView.setOnClickListener {
            openSocialMedia("https://www.instagram.com/your_profile")
        }

        facebookImageView.setOnClickListener {
            openSocialMedia("https://www.facebook.com/your_profile")
        }

        linkedinImageView.setOnClickListener {
            openSocialMedia("https://www.linkedin.com/in/your_profile")
        }

        return view
    }

    // Function to open social media links
    private fun openSocialMedia(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        startActivity(intent)
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment AboutUsFragment.
         */
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            AboutUsFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}
