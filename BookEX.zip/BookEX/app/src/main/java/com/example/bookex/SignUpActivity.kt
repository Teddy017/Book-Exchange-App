package com.example.bookex

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.bookex.databinding.ActivitySignupBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class SignUpActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var binding: ActivitySignupBinding
    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize View Binding
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance() // Initialize Firestore

        binding.btnSignUp.setOnClickListener {
            val username = binding.etUserNameSignUp.text.toString().trim()
            val email = binding.etEmailSignUp.text.toString().trim()
            val password = binding.etPasswordSignUp.text.toString().trim()
            val confirmPassword = binding.etConfirmPasswordSignUp.text.toString().trim()

            // Input validation
            if (username.isEmpty()) {
                binding.etUserNameSignUp.error = "Please enter your Username"
                binding.etEmailSignUp.requestFocus()
                return@setOnClickListener
            }
            if (email.isEmpty()) {
                binding.etEmailSignUp.error = "Please enter your email"
                binding.etEmailSignUp.requestFocus()
                return@setOnClickListener
            }

            if (password.isEmpty()) {
                binding.etPasswordSignUp.error = "Please enter a password"
                binding.etPasswordSignUp.requestFocus()
                return@setOnClickListener
            }

            if (confirmPassword.isEmpty()) {
                binding.etConfirmPasswordSignUp.error = "Please confirm your password"
                binding.etConfirmPasswordSignUp.requestFocus()
                return@setOnClickListener
            }

            if (password != confirmPassword) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Firebase sign-up process
            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        // Get the current user ID
                        val userId = auth.currentUser?.uid

                        // Create a user object to store in Firestore
                        val user = hashMapOf(
                            "username" to username,
                            "email" to email
                        )

                        // Store the user in Firestore under the "users" collection
                        userId?.let {
                            firestore.collection("users").document(it)
                                .set(user)
                                .addOnSuccessListener {
                                    Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show()
                                    finish()  // Optionally navigate back to login
                                }
                                .addOnFailureListener { e ->
                                    Toast.makeText(this, "Error saving user profile: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                        }
                    } else {
                        Toast.makeText(this, "Registration Failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
        }

        binding.tvLogin.setOnClickListener {
            finish()  // Close the sign-up activity and return to login
        }
    }
}
