package com.example.bookex

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import com.example.bookex.R
import com.google.android.material.button.MaterialButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.util.*

class ProfileFragment : Fragment() {

    private lateinit var profileImageView: ImageView
    private lateinit var nameTextView: TextView
    private lateinit var emailTextView: TextView
    private lateinit var editButton: MaterialButton
    private lateinit var logoutButton: MaterialButton
    private lateinit var db: FirebaseFirestore
    private var imageUri: Uri? = null
    private lateinit var storageRef: FirebaseStorage

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        // Initialize Firestore and Storage
        db = FirebaseFirestore.getInstance()
        storageRef = FirebaseStorage.getInstance()

        // Initialize Views
        profileImageView = view.findViewById(R.id.imageView)
        nameTextView = view.findViewById(R.id.nameTextView)
        emailTextView = view.findViewById(R.id.emailTextView)
        editButton = view.findViewById(R.id.editButton)
        logoutButton = view.findViewById(R.id.btn_logout)

        // Fetch user profile info
        fetchUserProfile()

        // Set click listener on profile image to open gallery
        profileImageView.setOnClickListener {
            openGallery()
        }

        // Set up button click listeners
        logoutButton.setOnClickListener {
            logoutUser()
        }

        return view
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        galleryLauncher.launch(intent)
    }

    // Activity Result to handle the image picked from gallery
    private val galleryLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                imageUri = result.data?.data
                profileImageView.setImageURI(imageUri) // Set selected image to ImageView
                uploadImageToFirebase()
            } else {
                Toast.makeText(requireContext(), "Image selection cancelled", Toast.LENGTH_SHORT).show()
            }
        }

    private fun uploadImageToFirebase() {
        imageUri?.let {
            val userId = FirebaseAuth.getInstance().currentUser?.uid
            userId?.let {
                val ref = storageRef.reference.child("profileImages/$userId.jpg")
                ref.putFile(imageUri!!)
                    .addOnSuccessListener {
                        Toast.makeText(requireContext(), "Profile image uploaded successfully", Toast.LENGTH_SHORT).show()
                    }
                    .addOnFailureListener {
                        Toast.makeText(requireContext(), "Failed to upload profile image", Toast.LENGTH_SHORT).show()
                    }
            }
        }
    }

    private fun fetchUserProfile() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        userId?.let {
            db.collection("users").document(it).get().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val document = task.result
                    if (document != null && document.exists()) {
                        val username = document.getString("username")
                        val email = document.getString("email")
                        nameTextView.text = username ?: "Username not found"
                        emailTextView.text = email ?: "Email not found"
                    }
                } else {
                    val exception = task.exception
                    exception?.printStackTrace()
                }
            }
        } ?: run {
            nameTextView.text = "User not logged in"
            emailTextView.text = "User not logged in"
        }
    }

    private fun logoutUser() {
        FirebaseAuth.getInstance().signOut()
        Toast.makeText(requireContext(), "Logged out successfully", Toast.LENGTH_SHORT).show()
        startActivity(Intent(requireContext(), LoginActivity::class.java))
        requireActivity().finish()
    }
}

