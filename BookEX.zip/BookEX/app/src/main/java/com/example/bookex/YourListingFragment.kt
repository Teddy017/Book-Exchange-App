package com.example.bookex

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

class YourListingFragment : Fragment() {

    private lateinit var itemsListView: ListView
    private lateinit var progressBar: ProgressBar
    private lateinit var emptyView: TextView // Add reference to the empty view
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private lateinit var itemsAdapter: ArrayAdapter<Item>
    private val itemsList = mutableListOf<Item>()
    private var listenerRegistration: ListenerRegistration? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_your_listing, container, false)
        itemsListView = view.findViewById(R.id.items_list_view)
        progressBar = view.findViewById(R.id.progress_bar)
        emptyView = view.findViewById(R.id.empty_view)

        itemsAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, itemsList)
        itemsListView.adapter = itemsAdapter

        // Load user's items from Firestore
        loadUserItems()

        itemsListView.setOnItemClickListener { parent, view, position, id ->
            // Handle item click (e.g., navigate to item details)
        }

        return view
    }

    private fun loadUserItems() {
        progressBar.visibility = View.VISIBLE
        val currentUserId = auth.currentUser?.uid

        // Query items where userId matches the current user's ID
        listenerRegistration = db.collection("items")
            .whereEqualTo("userId", currentUserId)
            .addSnapshotListener { snapshot, exception ->
                progressBar.visibility = View.GONE
                if (exception != null) {
                    Toast.makeText(requireContext(), "Error fetching items: ${exception.message}", Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    itemsList.clear()
                    for (document in snapshot.documents) {
                        val item = document.toObject(Item::class.java)?.apply {
                            id = document.id // Set document ID
                        }
                        item?.let { itemsList.add(it) }
                    }
                    itemsAdapter.notifyDataSetChanged()
                }
            }
    }

    // Add a function to delete the item
    private fun deleteItem(item: Item) {
        val currentUserId = auth.currentUser?.uid

        if (item.userId == currentUserId) {
            db.collection("items").document(item.id).delete()
                .addOnSuccessListener {
                    Toast.makeText(requireContext(), "Item removed successfully", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { exception ->
                    Toast.makeText(requireContext(), "Failed to remove item: ${exception.message}", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(requireContext(), "You can only delete your own items", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        listenerRegistration?.remove() // Stop listening for Firestore updates
    }
}
